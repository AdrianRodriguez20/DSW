<?php

class Direccion extends ModeloBase {

	private $calle;
    private $cp;
    private $provincia;
    private $numero;
	private $dni_persona;
	
	function __construct() {
		parent::__construct();
		$this->tabla = "direccion";
		$this->clavePrimaria = "dni_persona";
	}


    public function __get($name)
	{
	  return $this->$name;
	}
 
	 // METODOS (SET)
	public function __set($name, $value)
	{
	  return $this->$name = $value;
	}

}
