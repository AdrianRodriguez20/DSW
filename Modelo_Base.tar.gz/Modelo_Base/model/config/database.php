<?php
return array(
    "host"      =>"localhost",
    "user"      =>"Admin",
    "pass"      =>"123456",
    "database"  =>"Videoclub",
    "charset"   =>"utf8"
);
// $this->db= new mysqli("localhost", "Admin", "123456","Videoclub");
?>
