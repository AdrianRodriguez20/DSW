<?php
return array(
    "host"      =>"localhost",
    "user"      =>"Admin",
    "pass"      =>"123456",
    "database"  =>"Videoclub",
    "charset"   =>"utf8"
);

?>
