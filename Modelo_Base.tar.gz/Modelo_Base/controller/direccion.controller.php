<?php
require 'model/direccion.model.php';

class DireccionController{

    function index(){
        if (isset($_GET['dni_persona'])){
        $direccion = new Direccion();
        $listado = $direccion->buscar($_GET['dni_persona']);
        require_once 'views/direccion/direccion.php';
        }
    }

   public function crud (){
     $editar=false;
        if (isset($_GET['dni_persona'])){
            $direccion=new Direccion();
            $editar=true;
            $direccion=$direccion->buscar($_GET['dni_persona']);  
        }
     require_once 'views/direccion/insertar.php';
   }
    public function guardar(){
        
        $direccion=new Direccion();

        if ( $_POST['dni']){
         
            $direccion->__set("nombre",$_POST['nombre']);
            $direccion->__set("dni",$_POST['dni']);
            $direccion->__set("apellidos",$_POST["apellidos"]);
            $direccion->__set("edad",$_POST["edad"]);

            $valores=array("'".$direccion->__get("nombre")."'","'".$direccion->__get("apellidos")."'","'".$direccion->__get("dni")."'","'".$direccion->__get("edad")."'");
        }
       
        if(isset($_GET['dni'])){
            $array = array(
                "nombre" => $direccion->__get("nombre"),
                "apellidos" => $direccion->__get("apellidos"),
                "dni" => $direccion->__get("dni"),
                "edad" => $direccion->__get("edad"),
            );
            $direccion->modificar($array,$direccion->__get("dni"));
        }else{
            $direccion->insertar($direccion->argumentos,$valores);
        }
       header('Location: index.php?c=direccion');
     
    }
    public function eliminar(){
        $direccion=new Direccion();
        $direccion->eliminar($_GET['dni']);
        header('Location: index.php?c=direccion');
    }

    public function listar(){
        $direccion = new Direccion();
        //$listado = $direccion->listar($);
        require_once 'views/direccion/insertar.php';
    }
}