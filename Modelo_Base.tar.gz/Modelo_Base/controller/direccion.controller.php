<?php
require 'controller/validadores/direccion.validador.php';
class DireccionController{
    use validacionesDireccion;

   public function crud (){
     $editar=false;
        if (isset($_GET['dni'])){
            $direccion=new Direccion();
            $editar=true;
            $direccion=$direccion->buscar($_GET['dni']);  
        }
     require_once 'views/direccion/insertar.php';
   }
    public function guardar(){
      
        $direccion=new Direccion();
    
       //$this->validarCp($_GET['dni'])
       if(isset($_GET['dni'])){

            $direccion->__set("calle",$_POST['calle']);
            $direccion->__set("cp",$_POST['cp']);
            $direccion->__set("provincia",$_POST["provincia"]);
            $direccion->__set("numero",$_POST["numero"]);

            $arrayDireccion = array(
                "calle" => $direccion->__get("calle"),
                "cp" => $direccion->__get("cp"),
                "provincia" => $direccion->__get("provincia"),
                "numero" => $direccion->__get("numero"),
            );
            
            $direccion->modificar($arrayDireccion,$_GET['dni']);

        }
       header('Location: index.php?c=persona');
     
    }

 
}

?>
