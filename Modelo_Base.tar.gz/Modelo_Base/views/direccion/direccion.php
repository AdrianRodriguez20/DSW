<h1 class="page-header">Direcciones</h1>

<a class="btn btn-primary float-right" href="?c=direccion&a=crud">Agregar</a>
<br><br><br>

<table class="table  table-striped  table-hover" id="tabla">
    <thead>
        <tr>
        <th class="bg-dark text-white" style="width:120px;">DNI</th>
            <th class="bg-dark text-white" style="width:120px;">Calle</th>
            <th class="bg-dark text-white" style="width:180px;">Número</th>
            <th class="bg-dark text-white" style="width:180px;">CP</th>
            <th class="bg-dark text-white" style="width:180px;">Provincia</th>
            <th class="bg-dark text-white" style="width:60px;"></th>
            <th class="bg-dark text-white" style="width:60px;"></th>
        </tr>
    </thead>
    <tbody>
       
        <tr>
        <td><?=$direccion->dni_persona?></td>
        <td><?=$direccion->calle?></td>
        <td><?=$direccion->numero?></td>
        <td><?=$direccion->cp?></td>
        <td><?=$direccion->provincia?></td>

        <td>
            <a class="btn btn-warning" href="?c=direccion&a=crud&dni_persona=<?= $direccion->dni_persona; ?>">Editar</a>
        </td>
        <td>
            <a class="btn btn-danger" onclick="javascript:return confirm('¿Seguro de eliminar este registro?');"
                href="?c=direccion&a=eliminar&dni_persona=<?=$direccion->dni_persona; ?>">Eliminar</a>
        </td>
</td>

    </tbody>
</table>

</body>
<script src="assets/js/datatable.js">

</script>


</html>


</html>