<h1 class="page-header">
    <?=(isset($direccion) && is_object($direccion) ? $direccion->dni : '' != null) ? $direccion->dni : 'Nuevo Registro'; ?>
</h1>

<ol class="breadcrumb">
  <i><a href="?c=persona">persona</a><li>
  <i >&nbsp↳&nbsp</i>
  <i class="active"><?=((isset($direccion) && is_object($direccion) ? $direccion->dni : '' != null) != null) ? $direccion->dni  : 'Nuevo Registro'; ?><li>
</ol>
<?php 
    if ($editar){
       $accion ="?c=direccion&a=guardar&dni=$direccion->dni"; 
    }else { 
        $accion ="?c=direccion&a=guardar" ;
    }
        ?>

<form id="frm-persona" action="<?=$accion?>" method="post" enctype="multipart/form-data">

    <input type="hidden" name="id" />
        
    <div class="form-group">
        <label>Calle</label>
        <input type="text" name="calle" value="<?= isset($direccion) && is_object($direccion) ? $direccion->calle : ''; ?>" class="form-control"  placeholder="Ingrese su direccion" required>
    </div>

    <div class="form-group">
        <label>Código Postal</label>
        <input type="text" name="cp" value="<?= isset($direccion) && is_object($direccion) ? $direccion->cp : ''; ?>" class="form-control"  placeholder="Ingrese su direccion" required>
    </div>

    <div class="form-group">
        <label>Provincia</label>
        <input type="text" name="provincia" value="<?= isset($direccion) && is_object($direccion) ? $direccion->provincia : ''; ?>" class="form-control"  placeholder="Ingrese su direccion" required>
    </div>

    <div class="form-group">
        <label>Número</label>
        <input type="text" name="numero" value="<?= isset($direccion) && is_object($direccion) ? $direccion->numero : ''; ?>" class="form-control"  placeholder="Ingrese su direccion" required>
    </div>
    <hr />
    
    <div class="text-right">
        <button class="btn btn-success">Guardar</button>
    </div>
</form>
