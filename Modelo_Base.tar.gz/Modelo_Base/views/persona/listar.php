<h1 class="page-header">Persona</h1>


<a class="btn btn-primary float-right" href="?c=persona&a=crud">Agregar</a>
<br><br><br>

<table class="table  table-striped  table-hover" id="tabla">
    <thead>
        <tr>
        <th class="bg-dark text-white" style="width:120px;">Nombre</th>
            <th class="bg-dark text-white" style="width:120px;">Apellidos</th>
            <th class="bg-dark text-white" style="width:180px;">DNI</th>
            <th class="bg-dark text-white" style="width:180px;">Edad</th>
            <th class="bg-dark text-white" style="width:60px;"></th>
            <th class="bg-dark text-white" style="width:60px;"></th>
        </tr>
    </thead>
    <tbody>
        <?php if (count($listado)>0):foreach ($listado as $r):?>
        <tr>
        <td><?=$r["nombre"]?></td>
        <td><?=$r["apellidos"]?></td>
        <td><?=$r["dni"]?></td>
        <td><?=$r["edad"]?></td>

        <td>
            <a class="btn btn-warning" href="?c=persona&a=crud&dni=<?=$r["dni"]; ?>">Editar</a>
        </td>
        <td>
            <a class="btn btn-danger" onclick="javascript:return confirm('¿Seguro de eliminar este registro?');"
                href="?c=persona&a=eliminar&dni=<?=$r["dni"]; ?>">Eliminar</a>
        </td>
</td>
        <?php endforeach ;?>
        <?php endif ;?>
    </tbody>
</table>

</body>
<script src="assets/js/datatable.js">

</script>


</html>