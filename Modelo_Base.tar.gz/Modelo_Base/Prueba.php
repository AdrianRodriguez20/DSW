<?php
class Persona{
private $nombre;
private $apellidos;
private $dni;
private $edad;

    function __construct() {
    $this->tabla = "persona";
    $this->clavePrimaria = "dni";
    $this->argumentos=array("dni","nombre","apellidos","edad");
    }
     // METODOS (GET )
     public function __get($name)
     {
       return $this->$name;
     }
  
      // METODOS (SET)
     public function __set($name, $value)
     {
       return $this->$name = $value;
     }
}
$persona=new Persona();
$persona->__set("nombre","Adrian");
$persona->__set("apellidos","Rodríguez");
$persona->__set("dni","43494199A");
$persona->__set("edad","19");

$valores=array($persona->__get("dni"),$persona->__get("nombre"),$persona->__get("apellidos"),$persona->__get("edad"));

print_r($persona);
print_r($valores);
    print_r($persona->argumentos);
    

?>
